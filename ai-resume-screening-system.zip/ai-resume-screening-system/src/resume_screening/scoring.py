from dataclasses import dataclass

import numpy as np
from joblib import hash as joblib_hash
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from resume_screening.config import ATS_SECTION_WEIGHTS
from resume_screening.skills import SkillComparison, SkillExtractor
from resume_screening.text_processing import (
    detect_sections,
    estimate_years_experience,
    extract_soft_skills,
    normalize_text,
)


@dataclass(frozen=True)
class ResumeAnalysis:
    analysis_id: str
    ats_score: int
    similarity_score: int
    section_score: int
    skill_score: int
    keyword_score: int
    skill_comparison: SkillComparison
    sections: dict
    soft_skills: list
    programming_languages: list
    estimated_years_experience: int
    word_count: int


class ResumeAnalyzer:
    def __init__(self, skill_extractor=None):
        self.skill_extractor = skill_extractor or SkillExtractor()

    def analyze(self, resume_text, job_text):
        resume_text = normalize_text(resume_text)
        job_text = normalize_text(job_text)

        comparison = self.skill_extractor.compare(resume_text, job_text)

        similarity = self.calculate_similarity(resume_text, job_text)
        section_score = self.calculate_section_score(resume_text)
        skill_score = self.calculate_skill_score(comparison)
        keyword_score = self.calculate_keyword_score(resume_text, job_text)

        ats_score = round(
            similarity * 0.40
            + skill_score * 0.35
            + section_score * 0.15
            + keyword_score * 0.10
        )

        languages = sorted(
            set(comparison.resume_skills)
            & set(self.skill_extractor.taxonomy["Programming Languages"])
        )

        return ResumeAnalysis(
            analysis_id=joblib_hash((resume_text, job_text)),
            ats_score=int(np.clip(ats_score, 0, 100)),
            similarity_score=similarity,
            section_score=section_score,
            skill_score=skill_score,
            keyword_score=keyword_score,
            skill_comparison=comparison,
            sections=detect_sections(resume_text),
            soft_skills=extract_soft_skills(resume_text),
            programming_languages=languages,
            estimated_years_experience=estimate_years_experience(resume_text),
            word_count=len(resume_text.split()),
        )

    @staticmethod
    def calculate_similarity(resume_text, job_text):
        if not resume_text.strip() or not job_text.strip():
            return 0

        vectorizer = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
            min_df=1,
            lowercase=True,
        )

        try:
            matrix = vectorizer.fit_transform([resume_text, job_text])
        except ValueError:
            return 0

        score = cosine_similarity(matrix[0:1], matrix[1:2])[0][0]
        return int(round(float(score) * 100))

    @staticmethod
    def calculate_section_score(resume_text):
        sections = detect_sections(resume_text)
        weighted_score = sum(
            weight
            for section, weight in ATS_SECTION_WEIGHTS.items()
            if sections[section]
        )
        return int(round(weighted_score * 100))

    @staticmethod
    def calculate_skill_score(comparison):
        if not comparison.job_skills:
            return 70 if comparison.resume_skills else 0

        return int(
            round(
                len(comparison.matching_skills)
                / len(comparison.job_skills)
                * 100
            )
        )

    @staticmethod
    def calculate_keyword_score(resume_text, job_text):
        resume_words = {
            word.strip(".,:;()[]{}").lower()
            for word in resume_text.split()
            if len(word.strip(".,:;()[]{}")) > 3
        }

        job_words = {
            word.strip(".,:;()[]{}").lower()
            for word in job_text.split()
            if len(word.strip(".,:;()[]{}")) > 3
        }

        if not job_words:
            return 0

        overlap = resume_words & job_words
        return int(round(len(overlap) / len(job_words) * 100))
