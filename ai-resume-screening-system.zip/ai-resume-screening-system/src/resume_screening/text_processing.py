import re
from functools import lru_cache

import spacy


@lru_cache(maxsize=1)
def load_nlp():
    try:
        return spacy.load("en_core_web_sm")
    except OSError:
        return spacy.blank("en")


def normalize_text(text):
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def lower_clean_text(text):
    return re.sub(r"\s+", " ", normalize_text(text).lower())


def detect_sections(text):
    from resume_screening.config import SECTION_KEYWORDS

    cleaned = lower_clean_text(text)
    sections = {
        section: any(keyword in cleaned for keyword in keywords)
        for section, keywords in SECTION_KEYWORDS.items()
    }
    sections["contact"] = bool(
        re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", cleaned)
        or re.search(r"\+?\d[\d\s().-]{8,}\d", cleaned)
        or "linkedin.com" in cleaned
    )
    return sections


def extract_soft_skills(text):
    from resume_screening.config import SOFT_SKILLS

    cleaned = lower_clean_text(text)
    return sorted({skill for skill in SOFT_SKILLS if skill in cleaned})


def estimate_years_experience(text):
    cleaned = lower_clean_text(text)
    patterns = [
        r"(\d{1,2})\+?\s+years?\s+of\s+experience",
        r"(\d{1,2})\+?\s+years?\s+experience",
    ]

    matches = []
    for pattern in patterns:
        matches.extend(int(value) for value in re.findall(pattern, cleaned))

    return max(matches, default=0)
