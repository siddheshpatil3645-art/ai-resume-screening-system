def generate_suggestions(analysis, resume_text):
    suggestions = []

    if analysis.ats_score < 75:
        suggestions.append(
            "Increase alignment with the job description by adding exact, truthful keywords from the target role."
        )

    if analysis.skill_comparison.missing_skills:
        missing = ", ".join(sorted(analysis.skill_comparison.missing_skills)[:8])
        suggestions.append(
            f"Add relevant missing skills where you can support them with evidence: {missing}."
        )

    missing_sections = [
        section for section, present in analysis.sections.items() if not present
    ]

    if missing_sections:
        suggestions.append(
            "Add clearly labeled ATS-friendly sections for: "
            + ", ".join(missing_sections)
            + "."
        )

    if analysis.word_count < 350:
        suggestions.append(
            "The resume appears short. Add concise bullets for projects, internships, coursework, or measurable outcomes."
        )

    return suggestions or [
        "The resume is well aligned. Keep tailoring the summary and top bullets for each role."
    ]
