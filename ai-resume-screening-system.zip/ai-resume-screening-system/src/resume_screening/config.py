TECHNICAL_SKILLS = {
    "Programming Languages": [
        "python", "java", "javascript", "typescript", "c++", "c#",
        "go", "r", "sql", "bash"
    ],
    "Data Science & ML": [
        "machine learning", "deep learning", "nlp", "tensorflow",
        "pytorch", "scikit-learn", "sklearn", "pandas", "numpy",
        "matplotlib", "seaborn", "statistics"
    ],
    "Cloud & DevOps": [
        "aws", "azure", "gcp", "docker", "kubernetes", "linux",
        "github actions", "jenkins", "mlflow"
    ],
    "Databases": [
        "postgresql", "mysql", "sqlite", "mongodb", "redis", "snowflake"
    ],
    "Web & APIs": [
        "flask", "django", "fastapi", "streamlit", "react",
        "node.js", "rest api", "html", "css"
    ],
}

SOFT_SKILLS = [
    "communication", "leadership", "collaboration", "problem solving",
    "critical thinking", "adaptability", "time management", "ownership"
]

SECTION_KEYWORDS = {
    "education": ["education", "degree", "bachelor", "master", "university"],
    "experience": ["experience", "work history", "internship", "engineer"],
    "certifications": ["certification", "certified", "certificate"],
    "projects": ["project", "portfolio", "github", "built", "developed"],
}

ATS_SECTION_WEIGHTS = {
    "education": 0.20,
    "experience": 0.35,
    "certifications": 0.15,
    "projects": 0.20,
    "contact": 0.10,
}
