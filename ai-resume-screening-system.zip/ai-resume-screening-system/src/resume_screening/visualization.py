import pandas as pd
import plotly.graph_objects as go


def build_gauge(score):
    fig = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=score,
            number={"suffix": "/100"},
            gauge={
                "axis": {"range": [0, 100]},
                "bar": {"color": "#2dd4bf"},
                "steps": [
                    {"range": [0, 50], "color": "#7f1d1d"},
                    {"range": [50, 75], "color": "#854d0e"},
                    {"range": [75, 100], "color": "#14532d"},
                ],
            },
            title={"text": "ATS Compatibility"},
        )
    )
    fig.update_layout(height=300)
    return fig


def build_skill_pie(analysis):
    comparison = analysis.skill_comparison
    data = pd.DataFrame(
        {
            "status": ["Matching", "Missing", "Extra"],
            "count": [
                len(comparison.matching_skills),
                len(comparison.missing_skills),
                len(comparison.extra_skills),
            ],
        }
    )

    fig = go.Figure(
        go.Pie(
            labels=data["status"],
            values=data["count"],
            hole=0.55,
            marker={"colors": ["#22c55e", "#ef4444", "#38bdf8"]},
        )
    )
    fig.update_layout(height=300)
    return fig


def build_score_bar(analysis):
    data = pd.DataFrame(
        {
            "component": ["Similarity", "Skills", "Sections", "Keywords"],
            "score": [
                analysis.similarity_score,
                analysis.skill_score,
                analysis.section_score,
                analysis.keyword_score,
            ],
        }
    )

    fig = go.Figure(
        go.Bar(
            x=data["component"],
            y=data["score"],
            marker_color=["#60a5fa", "#2dd4bf", "#f59e0b", "#a78bfa"],
            text=[f"{value}%" for value in data["score"]],
            textposition="outside",
        )
    )
    fig.update_yaxes(range=[0, 110])
    fig.update_layout(height=320)
    return fig


def build_category_bar(by_category):
    data = pd.DataFrame(
        {
            "category": list(by_category.keys()),
            "count": [len(skills) for skills in by_category.values()],
        }
    )

    fig = go.Figure(
        go.Bar(
            x=data["count"],
            y=data["category"],
            orientation="h",
            marker_color="#14b8a6",
            text=data["count"],
        )
    )
    fig.update_layout(height=320)
    return fig
