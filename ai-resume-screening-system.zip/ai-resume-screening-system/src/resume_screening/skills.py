import re
from dataclasses import dataclass

from resume_screening.config import TECHNICAL_SKILLS
from resume_screening.text_processing import lower_clean_text


@dataclass(frozen=True)
class SkillComparison:
    resume_skills: set
    job_skills: set
    matching_skills: set
    missing_skills: set
    extra_skills: set
    by_category: dict


class SkillExtractor:
    def __init__(self, taxonomy=None):
        self.taxonomy = taxonomy or TECHNICAL_SKILLS
        self._skill_to_category = {
            skill: category
            for category, skills in self.taxonomy.items()
            for skill in skills
        }

    @property
    def all_skills(self):
        return set(self._skill_to_category)

    def extract(self, text):
        cleaned = lower_clean_text(text)
        found = set()

        for skill in self.all_skills:
            pattern = rf"(?<![a-z0-9+#]){re.escape(skill)}(?![a-z0-9+#])"
            if re.search(pattern, cleaned):
                found.add(self._canonical_skill(skill))

        return found

    def compare(self, resume_text, job_text):
        resume_skills = self.extract(resume_text)
        job_skills = self.extract(job_text)

        return SkillComparison(
            resume_skills=resume_skills,
            job_skills=job_skills,
            matching_skills=resume_skills & job_skills,
            missing_skills=job_skills - resume_skills,
            extra_skills=resume_skills - job_skills,
            by_category=self.group_by_category(resume_skills),
        )

    def group_by_category(self, skills):
        grouped = {category: [] for category in self.taxonomy}

        for skill in sorted(skills):
            category = self._skill_to_category.get(skill)
            if category:
                grouped[category].append(skill)

        return {category: values for category, values in grouped.items() if values}

    @staticmethod
    def _canonical_skill(skill):
        aliases = {
            "sklearn": "scikit-learn",
            "natural language processing": "nlp",
        }
        return aliases.get(skill, skill)
