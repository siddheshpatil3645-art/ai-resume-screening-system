from io import BytesIO

import pdfplumber

from resume_screening.text_processing import normalize_text


def extract_text_from_pdf(file_obj):
    pages = []

    with pdfplumber.open(file_obj) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text(x_tolerance=1, y_tolerance=3) or ""
            if page_text:
                pages.append(page_text)

    return normalize_text("\n\n".join(pages))


def extract_text_from_upload(uploaded_file):
    file_name = uploaded_file.name.lower()
    file_bytes = BytesIO(uploaded_file.getvalue())

    if file_name.endswith(".pdf"):
        return extract_text_from_pdf(file_bytes)

    if file_name.endswith(".txt"):
        return normalize_text(file_bytes.getvalue().decode("utf-8", errors="ignore"))

    raise ValueError("Unsupported file type. Upload PDF or TXT.")
