# AI Resume Screening System

An AI-powered Streamlit application that analyzes resumes against job descriptions.

## Features

- PDF resume upload
- Job description paste/upload
- ATS score from 0 to 100
- TF-IDF cosine similarity
- Technical skill extraction
- Matching, missing, and extra skill analysis
- Resume section analysis
- AI-style resume improvement suggestions
- Plotly dashboard visualizations
- Dark theme support

## Tech Stack

Python, Streamlit, Scikit-learn, Pandas, NumPy, spaCy, pdfplumber, Plotly, Joblib

## Run Locally

```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm
streamlit run app/main.py
