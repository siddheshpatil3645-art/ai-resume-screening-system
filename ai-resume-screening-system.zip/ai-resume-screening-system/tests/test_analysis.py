from resume_screening.scoring import ResumeAnalyzer
from resume_screening.skills import SkillExtractor


RESUME_TEXT = """
Jane Candidate
jane@example.com

Education
Bachelor of Science in Computer Science

Experience
Machine Learning Intern with 2 years of experience building Python dashboards.
Built a Streamlit project using pandas, numpy, scikit-learn, SQL, and Plotly.

Projects
AI resume analyzer deployed with Docker.
"""

JOB_TEXT = """
We need an AI engineer with Python, SQL, pandas, numpy,
scikit-learn, machine learning, Streamlit, Docker, communication,
and dashboard experience.
"""


def test_skill_extractor():
    skills = SkillExtractor().extract(RESUME_TEXT)

    assert "python" in skills
    assert "scikit-learn" in skills
    assert "streamlit" in skills
    assert "docker" in skills


def test_resume_analyzer():
    analysis = ResumeAnalyzer().analyze(RESUME_TEXT, JOB_TEXT)

    assert 0 <= analysis.ats_score <= 100
    assert 0 <= analysis.similarity_score <= 100
    assert analysis.sections["education"] is True
    assert analysis.sections["experience"] is True
    assert analysis.estimated_years_experience == 2
