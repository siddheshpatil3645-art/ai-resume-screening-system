import sys
from pathlib import Path

import streamlit as st

ROOT_DIR = Path(__file__).resolve().parents[1]
SRC_DIR = ROOT_DIR / "src"

if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from resume_screening.pdf_parser import extract_text_from_upload
from resume_screening.scoring import ResumeAnalyzer
from resume_screening.suggestions import generate_suggestions
from resume_screening.visualization import (
    build_category_bar,
    build_gauge,
    build_score_bar,
    build_skill_pie,
)


st.set_page_config(
    page_title="AI Resume Screening System",
    layout="wide",
    initial_sidebar_state="expanded",
)


def render_skill_pills(title, skills):
    st.subheader(title)

    if not skills:
        st.caption("No skills found.")
        return

    st.write(", ".join(sorted(skills)))


def read_job_description(uploaded_file, pasted_text):
    if uploaded_file is not None:
        return extract_text_from_upload(uploaded_file)

    return pasted_text.strip()


def main():
    st.title("AI Resume Screening System")
    st.caption("ATS scoring, skill gap analysis, semantic matching, and resume guidance.")

    with st.sidebar:
        st.header("Inputs")
        resume_file = st.file_uploader("Upload resume PDF", type=["pdf"])
        jd_file = st.file_uploader("Upload job description", type=["pdf", "txt"])
        pasted_jd = st.text_area("Or paste job description", height=260)
        analyze_clicked = st.button("Analyze Resume", type="primary")

    if not analyze_clicked:
        st.info("Upload a resume and provide a job description to begin.")
        return

    if resume_file is None:
        st.error("Please upload a resume PDF.")
        return

    resume_text = extract_text_from_upload(resume_file)
    job_text = read_job_description(jd_file, pasted_jd)

    if not resume_text or not job_text:
        st.error("Both resume and job description are required.")
        return

    analyzer = ResumeAnalyzer()
    analysis = analyzer.analyze(resume_text, job_text)
    suggestions = generate_suggestions(analysis, resume_text)

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("ATS Score", f"{analysis.ats_score}/100")
    col2.metric("Similarity", f"{analysis.similarity_score}%")
    col3.metric("Skill Match", f"{analysis.skill_score}%")
    col4.metric("Words Parsed", f"{analysis.word_count:,}")

    st.progress(analysis.ats_score / 100)

    left, right = st.columns(2)

    with left:
        st.plotly_chart(build_gauge(analysis.ats_score), use_container_width=True)

    with right:
        st.plotly_chart(build_skill_pie(analysis), use_container_width=True)

    st.subheader("Scoring Breakdown")
    st.plotly_chart(build_score_bar(analysis), use_container_width=True)

    st.subheader("Skill Gap Analysis")
    c1, c2, c3 = st.columns(3)

    with c1:
        render_skill_pills("Matching Skills", analysis.skill_comparison.matching_skills)

    with c2:
        render_skill_pills("Missing Skills", analysis.skill_comparison.missing_skills)

    with c3:
        render_skill_pills("Extra Skills", analysis.skill_comparison.extra_skills)

    st.subheader("Resume Analysis")
    st.write("Sections:", analysis.sections)
    st.write("Programming Languages:", analysis.programming_languages)
    st.write("Soft Skills:", analysis.soft_skills)
    st.write("Estimated Years of Experience:", analysis.estimated_years_experience)

    if analysis.skill_comparison.by_category:
        st.subheader("Resume Skills by Category")
        st.plotly_chart(
            build_category_bar(analysis.skill_comparison.by_category),
            use_container_width=True,
        )

    st.subheader("AI Suggestions")
    for suggestion in suggestions:
        st.write("-", suggestion)


if __name__ == "__main__":
    main()
